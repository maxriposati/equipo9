import { TableAprovarSolicitudes } from "./TableAprovarSolicitudes";

export default TableAprovarSolicitudes;



