import { Politicas } from "./Politicas"
export default Politicas