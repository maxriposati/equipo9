import { FormMainEmp } from "./FormMainEmp";
export default FormMainEmp;

